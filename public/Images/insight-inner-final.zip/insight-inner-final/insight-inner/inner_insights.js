"use client";

import Main from './components/inner_insight_main';
import Side from './components/inner_insight_side';
import { Box, Grid } from '@mui/material';
import Heading from './components/Heading';
import SearchBar from '../Insights/components/SearchBar';
import CategoriesSidebar from '../Insights/components/CategoriesSidebar';
import LatestProperties from '../Insights/components/LatestProperties';
import Tags from '../Insights/components/Tags';
import BlogCard from '../Insights/components/Blogcards';
import { Container } from "@mui/material"

export default function InnerInsights() {
  return (
    <Box sx={{ backgroundColor: "#F7F7F7", minHeight: "100vh", overflowX: "hidden" }}>
      <Container
        maxWidth="lg"
        sx={{
          py: 6,
        }}
      >
        <Heading />

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "3fr 1fr" }, // Adjust column ratios for bigger space in Main content
            gap: { xs: 4, md: 3 },
            mt: 5,
            overflow: "hidden", // Prevent overflow issues
          }}
        >
          {/* Main Content */}
          <Box
            sx={{
              overflow: "hidden",  // Ensure no horizontal overflow for Main content
              width: "100%", // Ensure Main content fits within bounds
            }}
          >
            <Main />
          </Box>

          {/* Sidebar */}
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
              mt: 3,
              width: "100%",  // Sidebar width should be responsive
              maxWidth: "100%",
              // Sidebar should occupy less space (especially on larger screens)
              minWidth: { sm: "200px", md: "250px" }, // Set a minimum width for the sidebar
              overflow: "hidden",
            }}
          >
            {/* Search */}
            <Box>
              <SearchBar />
            </Box>

            {/* Categories */}
            <CategoriesSidebar />

            {/* Latest Properties */}
            <LatestProperties />

            {/* Tags */}
            <Tags />
          </Box>
        </Box>
      </Container>
    </Box>
  );
}
